#include <stdio.h>
#include <stdlib.h> // cho phep hien thi doan van len man hinh

int main(void)
{
    printf("Hello World!");
    getchar();
    return 0;
}