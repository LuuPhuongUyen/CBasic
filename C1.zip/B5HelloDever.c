#include <stdio.h>
#include <conio.h>

int main(void)
{
    char c[40];
    printf("Nhap ten:"); scanf("%s", &c);
    printf("%s la thanh vien FU-Dever", c);
    getch();
}